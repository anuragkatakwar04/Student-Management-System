import tkinter as tk
from tkinter import ttk, messagebox
from student_db import StudentDB

class StudentApp:
    def __init__(self, root):
        self.db = StudentDB()
        self.root = root
        self.root.title("Student Management System")
        self.root.geometry("1000x600")
        self.root.configure(bg="#ECF0F1")

        title = tk.Label(root, text="Student Management System",
                         font=("Arial", 24, "bold"), bg="#2C3E50", fg="white")
        title.pack(fill=tk.X)

        # ========== Input Frame ==========
        frame = tk.Frame(root, bg="#ECF0F1")
        frame.place(x=20, y=70)

        labels = ["Name", "Roll No", "Course", "Email", "Phone"]
        self.entries = {}

        for i, label in enumerate(labels):
            tk.Label(frame, text=label, font=("Arial", 14), bg="#ECF0F1").grid(row=i, column=0, pady=10, sticky="w")

            entry = tk.Entry(frame, font=("Arial", 14), width=25)
            entry.grid(row=i, column=1)
            self.entries[label] = entry

        # ========== Buttons ==========
        btn_frame = tk.Frame(root, bg="#ECF0F1")
        btn_frame.place(x=20, y=350)

        btn_specs = [
            ("Add", self.add_student),
            ("Update", self.update_student),
            ("Delete", self.delete_student),
            ("Search", self.search_student),
            ("View All", self.view_students)
        ]

        for i, (text, cmd) in enumerate(btn_specs):
            tk.Button(btn_frame, text=text, width=12, font=("Arial", 14),
                      bg="#3498DB", fg="white", command=cmd).grid(row=0, column=i, padx=10)

        # ========== Table Frame ==========
        table_frame = tk.Frame(root)
        table_frame.place(x=400, y=70)

        columns = ("ID", "Name", "Roll", "Course", "Email", "Phone")
        self.table = ttk.Treeview(table_frame, columns=columns, show="headings")

        for col in columns:
            self.table.heading(col, text=col)
            self.table.column(col, width=120)

        self.table.pack(fill=tk.BOTH, expand=True)

    # ============ Functions ===============
    def add_student(self):
        data = [self.entries[x].get() for x in self.entries]
        if "" in data:
            messagebox.showwarning("Error", "Fill all fields")
            return
        try:
            self.db.add_student(*data)
            messagebox.showinfo("Success", "Student added successfully!")
            self.view_students()
        except:
            messagebox.showerror("Error", "Roll Number must be unique!")

    def view_students(self):
        for row in self.table.get_children():
            self.table.delete(row)

        for row in self.db.fetch_students():
            self.table.insert("", tk.END, values=row)

    def delete_student(self):
        roll = self.entries["Roll No"].get()
        if roll == "":
            messagebox.showwarning("Error", "Enter Roll No")
            return
        self.db.delete_student(roll)
        messagebox.showinfo("Deleted", "Student Deleted Successfully")
        self.view_students()

    def update_student(self):
        name = self.entries["Name"].get()
        roll = self.entries["Roll No"].get()
        course = self.entries["Course"].get()
        email = self.entries["Email"].get()
        phone = self.entries["Phone"].get()

        if roll == "":
            messagebox.showwarning("Error", "Enter Roll No")
            return

        self.db.update_student(name, course, email, phone, roll)
        messagebox.showinfo("Updated", "Student Updated")
        self.view_students()

    def search_student(self):
        roll = self.entries["Roll No"].get()
        data = self.db.search_student(roll)

        if data:
            messagebox.showinfo("Student Found",
                                f"Name: {data[1]}\nCourse: {data[3]}\nEmail: {data[4]}\nPhone: {data[5]}")
        else:
            messagebox.showerror("Not Found", "No student found!")

# ========== Run Program ==========
root = tk.Tk()
app = StudentApp(root)
root.mainloop()
