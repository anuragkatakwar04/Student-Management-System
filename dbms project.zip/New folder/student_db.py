import sqlite3

class StudentDB:
    def __init__(self):
        self.conn = sqlite3.connect("students.db")
        self.create_table()

    def create_table(self):
        query = """
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            roll TEXT UNIQUE,
            course TEXT,
            email TEXT,
            phone TEXT
        )
        """
        self.conn.execute(query)
        self.conn.commit()

    def add_student(self, name, roll, course, email, phone):
        query = "INSERT INTO students (name, roll, course, email, phone) VALUES (?, ?, ?, ?, ?)"
        self.conn.execute(query, (name, roll, course, email, phone))
        self.conn.commit()

    def fetch_students(self):
        cursor = self.conn.execute("SELECT * FROM students")
        return cursor.fetchall()

    def delete_student(self, roll):
        self.conn.execute("DELETE FROM students WHERE roll=?", (roll,))
        self.conn.commit()

    def update_student(self, name, course, email, phone, roll):
        query = "UPDATE students SET name=?, course=?, email=?, phone=? WHERE roll=?"
        self.conn.execute(query, (name, course, email, phone, roll))
        self.conn.commit()

    def search_student(self, roll):
        cursor = self.conn.execute("SELECT * FROM students WHERE roll=?", (roll,))
        return cursor.fetchone()
